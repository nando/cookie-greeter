<%= include 'HEADER' %>

var CookieGreeterMeta = {
  Version: '<%= APP_VERSION %>'
};

<%= include 'cookie_greeter_lib.js' %>
